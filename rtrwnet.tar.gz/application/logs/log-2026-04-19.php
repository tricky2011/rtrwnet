<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2026-04-19 00:00:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-19 00:00:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-19 00:05:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-19 00:05:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-19 00:10:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-19 00:10:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-19 00:55:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-19 00:55:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-19 01:00:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-19 01:00:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-19 01:05:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-19 01:05:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-19 01:10:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-19 01:10:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-19 01:15:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-19 01:15:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-19 01:20:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-19 01:20:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-19 01:25:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-19 01:25:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-19 01:30:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-19 01:30:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-19 01:35:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-19 01:35:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-19 01:40:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-19 01:40:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-19 01:45:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-19 01:45:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-19 01:50:02 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-19 01:50:02 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-19 01:55:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-19 01:55:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-19 02:40:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-19 02:40:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-19 02:45:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-19 02:45:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-19 02:50:02 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-19 02:50:02 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-19 02:55:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-19 02:55:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-19 03:00:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-19 03:00:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-19 03:05:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-19 03:05:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-19 03:10:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-19 03:10:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-19 03:15:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-19 03:15:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-19 03:20:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-19 03:20:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-19 03:25:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-19 03:25:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-19 03:30:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-19 03:30:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-19 03:35:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-19 03:35:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-19 03:40:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-19 03:40:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-19 03:45:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-19 03:45:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-19 03:50:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-19 03:50:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-19 03:55:02 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-19 03:55:02 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-19 04:00:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-19 04:00:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-19 05:40:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-19 05:40:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-19 05:45:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-19 05:45:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-19 05:50:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-19 05:50:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-19 12:20:02 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-19 12:20:02 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-19 18:05:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-19 18:05:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
