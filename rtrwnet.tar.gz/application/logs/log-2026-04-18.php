<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2026-04-18 00:25:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-18 00:25:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-18 00:30:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-18 00:30:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-18 00:35:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-18 00:35:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-18 00:40:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-18 00:40:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-18 00:45:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-18 00:45:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-18 00:50:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-18 00:50:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-18 00:55:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-18 00:55:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-18 01:00:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-18 01:00:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-18 01:05:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-18 01:05:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-18 01:10:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-18 01:10:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-18 01:15:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-18 01:15:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-18 01:20:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-18 01:20:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-18 01:25:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-18 01:25:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-18 02:10:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-18 02:10:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-18 02:15:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-18 02:15:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-18 02:20:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-18 02:20:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-18 02:25:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-18 02:25:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-18 02:30:02 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-18 02:30:02 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-18 02:35:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-18 02:35:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-18 02:40:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-18 02:40:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-18 02:45:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-18 02:45:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-18 02:50:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-18 02:50:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-18 02:55:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-18 02:55:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-18 03:00:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-18 03:00:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-18 03:05:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-18 03:05:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-18 03:10:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-18 03:10:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-18 03:15:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-18 03:15:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-18 03:20:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-18 03:20:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-18 03:25:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-18 03:25:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-18 03:30:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-18 03:30:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-18 03:35:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-18 03:35:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-18 05:10:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-18 05:10:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-18 05:15:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-18 05:15:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-18 05:20:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-18 05:20:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-18 05:25:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-18 05:25:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-18 11:15:02 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-18 11:15:02 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-18 16:00:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-18 16:00:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-18 16:05:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-18 16:05:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-18 16:10:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-18 16:10:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-18 18:45:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-18 18:45:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-18 18:50:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-18 18:50:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-18 18:55:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-18 18:55:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-18 21:40:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-18 21:40:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-18 21:45:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-18 21:45:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-18 21:50:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-18 21:50:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
ERROR - 2026-04-18 21:55:01 --> Query error: Disk full (/tmp/#sql_340_0.MAI); waiting for someone to free some space... (errno: 28 "No space left on device") - Invalid query: SHOW COLUMNS FROM `routers`
ERROR - 2026-04-18 21:55:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /var/www/rtrwnet/system/database/DB_driver.php 1332
