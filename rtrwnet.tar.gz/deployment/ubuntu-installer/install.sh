#!/usr/bin/env bash
set -euo pipefail

umask 027

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "${SCRIPT_DIR}/../.." && pwd)"
CONFIG_EXAMPLE_FILE="${SCRIPT_DIR}/config.env.example"
BACKUP_SUFFIX="$(date +%Y%m%d_%H%M%S)"

APT_UPDATED=0
MYSQL_SERVICE="mysql"
OS_ID=""
OS_VERSION_ID=""
OS_PRETTY_NAME=""
DEFAULT_PHP_VERSION=""
CONFIG_FILE=""
CONFIG_DIR=""
SOURCE_ROOT="${PROJECT_ROOT}"
SOURCE_ROOT_CANONICAL="${PROJECT_ROOT}"
INSTALLER_SOURCE_DIR="${SCRIPT_DIR}"
ENV_TEMPLATE_FILE="${PROJECT_ROOT}/.env.example"
NGINX_TEMPLATE_FILE="${SCRIPT_DIR}/nginx/rtrwnet.conf.template"
WORKER_TEMPLATE_FILE="${SCRIPT_DIR}/examples/rtrwnet-worker.service.example"
CRON_TEMPLATE_FILE="${SCRIPT_DIR}/examples/rtrwnet-crontab.example"
PACKAGE_ALLOWLIST_FILE="${SCRIPT_DIR}/package.allowlist"
PACKAGE_DENYLIST_FILE="${SCRIPT_DIR}/package.denylist"
STAGING_DIR=""

SUMMARY_ITEMS=()
VERIFICATION_ITEMS=()

log() {
    printf '[INFO] %s\n' "$*"
}

warn() {
    printf '[WARN] %s\n' "$*" >&2
}

die() {
    printf '[ERROR] %s\n' "$*" >&2
    exit 1
}

add_summary() {
    SUMMARY_ITEMS+=("$*")
}

add_verification() {
    VERIFICATION_ITEMS+=("$*")
}

cleanup() {
    if [ -n "${STAGING_DIR:-}" ] && [ -d "$STAGING_DIR" ]; then
        rm -rf "$STAGING_DIR"
    fi
}

trap cleanup EXIT

backup_path() {
    local target="$1"

    if [ -e "$target" ] || [ -L "$target" ]; then
        local backup="${target}.bak.${BACKUP_SUFFIX}"
        cp -a "$target" "$backup"
        add_summary "Backup dibuat: ${backup}"
    fi
}

require_root() {
    if [ "${EUID}" -ne 0 ]; then
        die "Jalankan installer dengan hak root, misalnya: sudo bash install.sh"
    fi
}

canonical_path() {
    local target="$1"

    if [ -e "$target" ] || [ -L "$target" ]; then
        readlink -f "$target"
        return
    fi

    local dir base
    dir="$(cd "$(dirname "$target")" && pwd)"
    base="$(basename "$target")"
    printf '%s/%s\n' "$dir" "$base"
}

path_is_within() {
    local candidate="$1"
    local root="$2"
    local candidate_path root_path

    candidate_path="$(canonical_path "$candidate")"
    root_path="$(canonical_path "$root")"

    case "$candidate_path" in
        "$root_path"|"$root_path"/*)
            return 0
            ;;
    esac

    return 1
}

detect_supported_os() {
    if [ ! -f /etc/os-release ]; then
        die "File /etc/os-release tidak ditemukan. Installer hanya mendukung Debian/Ubuntu."
    fi

    # shellcheck disable=SC1091
    . /etc/os-release

    OS_ID="${ID:-}"
    OS_VERSION_ID="${VERSION_ID:-}"
    OS_PRETTY_NAME="${PRETTY_NAME:-unknown}"

    case "${OS_ID}" in
        ubuntu|debian)
            ;;
        *)
            die "Installer ini hanya mendukung Debian/Ubuntu. Sistem terdeteksi: ${OS_PRETTY_NAME}"
            ;;
    esac

    case "${OS_ID}:${OS_VERSION_ID}" in
        ubuntu:22.04)
            DEFAULT_PHP_VERSION="8.1"
            ;;
        ubuntu:24.04)
            DEFAULT_PHP_VERSION="8.3"
            ;;
        debian:12)
            DEFAULT_PHP_VERSION="8.2"
            ;;
        *)
            DEFAULT_PHP_VERSION=""
            warn "OS ${OS_PRETTY_NAME} terdeteksi. Target utama installer ini adalah Ubuntu 22.04, Ubuntu 24.04, dan Debian 12. Isi PHP_VERSION secara eksplisit bila distro Anda berbeda."
            ;;
    esac
}

discover_config_file() {
    local candidate

    for candidate in \
        "${RTRWNET_INSTALLER_CONFIG:-}" \
        "/root/rtrwnet-installer.env" \
        "${SCRIPT_DIR}/config.env"
    do
        [ -n "$candidate" ] || continue
        if [ -f "$candidate" ]; then
            printf '%s\n' "$candidate"
            return 0
        fi
    done

    return 1
}

load_config() {
    if CONFIG_FILE="$(discover_config_file)"; then
        CONFIG_FILE="$(canonical_path "$CONFIG_FILE")"
        CONFIG_DIR="$(dirname "$CONFIG_FILE")"
        set -a
        # shellcheck disable=SC1090
        . "$CONFIG_FILE"
        set +a
        log "Memuat konfigurasi installer dari ${CONFIG_FILE}"
        return
    fi

    CONFIG_FILE=""
    CONFIG_DIR=""
    warn "File konfigurasi installer tidak ditemukan. Installer akan mencoba membaca nilai dari environment shell."
}

normalize_config() {
    APP_NAME="${APP_NAME:-RTRWNet Production}"
    SOURCE_ROOT="${SOURCE_ROOT:-$PROJECT_ROOT}"
    SOURCE_ROOT="${SOURCE_ROOT%/}"
    [ -n "$SOURCE_ROOT" ] || SOURCE_ROOT="/"
    SOURCE_ROOT_CANONICAL="$(canonical_path "$SOURCE_ROOT")"

    INSTALLER_SOURCE_DIR="${SOURCE_ROOT_CANONICAL}/deployment/ubuntu-installer"
    ENV_TEMPLATE_FILE="${SOURCE_ROOT_CANONICAL}/.env.example"
    NGINX_TEMPLATE_FILE="${INSTALLER_SOURCE_DIR}/nginx/rtrwnet.conf.template"
    WORKER_TEMPLATE_FILE="${INSTALLER_SOURCE_DIR}/examples/rtrwnet-worker.service.example"
    CRON_TEMPLATE_FILE="${INSTALLER_SOURCE_DIR}/examples/rtrwnet-crontab.example"
    PACKAGE_ALLOWLIST_FILE="${INSTALLER_SOURCE_DIR}/package.allowlist"
    PACKAGE_DENYLIST_FILE="${INSTALLER_SOURCE_DIR}/package.denylist"

    APP_DOMAIN="${APP_DOMAIN:-}"
    APP_SERVER_ALIASES="${APP_SERVER_ALIASES:-}"
    APP_ROOT="${APP_ROOT:-}"
    APP_ROOT="${APP_ROOT%/}"
    if [ -z "$APP_ROOT" ]; then
        APP_ROOT="/var/www/rtrwnet"
    fi

    NGINX_CONF_NAME="${NGINX_CONF_NAME:-rtrwnet.conf}"
    if [[ "$NGINX_CONF_NAME" != *.conf ]]; then
        NGINX_CONF_NAME="${NGINX_CONF_NAME}.conf"
    fi

    CI_ENV="${CI_ENV:-production}"
    PHP_VERSION="${PHP_VERSION:-$DEFAULT_PHP_VERSION}"
    PHP_FPM_SOCK="${PHP_FPM_SOCK:-}"
    if [ -n "$PHP_VERSION" ] && [ -z "$PHP_FPM_SOCK" ]; then
        PHP_FPM_SOCK="/run/php/php${PHP_VERSION}-fpm.sock"
    fi
    PHP_BIN="${PHP_BIN:-}"

    WEB_USER="${WEB_USER:-www-data}"
    WEB_GROUP="${WEB_GROUP:-www-data}"

    DB_HOST="${DB_HOST:-127.0.0.1}"
    DB_PORT="${DB_PORT:-3306}"
    DB_NAME="${DB_NAME:-}"
    DB_USER="${DB_USER:-}"
    DB_PASS="${DB_PASS:-}"
    DB_ROOT_PASS="${DB_ROOT_PASS:-}"
    SQL_FILE="${SQL_FILE:-}"
    ENABLE_DB_MIGRATIONS="${ENABLE_DB_MIGRATIONS:-1}"

    CI_ENCRYPTION_KEY="${CI_ENCRYPTION_KEY:-}"
    PROVISIONING_CALLBACK_SECRET="${PROVISIONING_CALLBACK_SECRET:-}"
    TELEGRAM_WEBHOOK_SECRET="${TELEGRAM_WEBHOOK_SECRET:-}"
    CRON_TOKEN="${CRON_TOKEN:-}"
    MONITORING_CRON_TOKEN="${MONITORING_CRON_TOKEN:-}"
    TELEGRAM_BOT_TOKEN="${TELEGRAM_BOT_TOKEN:-}"

    ENABLE_REDIS="${ENABLE_REDIS:-0}"
    REDIS_HOST="${REDIS_HOST:-127.0.0.1}"
    REDIS_PORT="${REDIS_PORT:-6379}"
    REDIS_DB="${REDIS_DB:-0}"
    REDIS_PASSWORD="${REDIS_PASSWORD:-}"
    REDIS_PREFIX="${REDIS_PREFIX:-rtrwnet:}"

    ENABLE_WORKER="${ENABLE_WORKER:-1}"
    WORKER_SERVICE_NAME="${WORKER_SERVICE_NAME:-rtrwnet-worker.service}"
    if [[ "$WORKER_SERVICE_NAME" != *.service ]]; then
        WORKER_SERVICE_NAME="${WORKER_SERVICE_NAME}.service"
    fi

    ENABLE_CRON="${ENABLE_CRON:-1}"
    CRON_FILE_NAME="${CRON_FILE_NAME:-rtrwnet}"

    ENABLE_PHPMYADMIN="${ENABLE_PHPMYADMIN:-0}"
    PHPMYADMIN_URL="${PHPMYADMIN_URL:-/phpmyadmin}"
    PHPMYADMIN_URL="/${PHPMYADMIN_URL#/}"
    PHPMYADMIN_URL="${PHPMYADMIN_URL%/}"
    if [ -z "$PHPMYADMIN_URL" ]; then
        PHPMYADMIN_URL="/phpmyadmin"
    fi

    APP_SERVER_NAMES="${APP_DOMAIN}"
    if [ -n "$APP_SERVER_ALIASES" ]; then
        APP_SERVER_NAMES="${APP_SERVER_NAMES} ${APP_SERVER_ALIASES}"
    fi
    APP_SERVER_NAMES="${APP_SERVER_NAMES} _"

    if [ "${ENABLE_REDIS}" = "1" ]; then
        QUEUE_DRIVER="redis"
    else
        QUEUE_DRIVER="database"
    fi

    if [ "${ENABLE_WORKER}" = "1" ]; then
        QUEUE_ENABLE_ASYNC="1"
    else
        QUEUE_ENABLE_ASYNC="0"
    fi

    NGINX_CONF_TARGET="/etc/nginx/sites-available/${NGINX_CONF_NAME}"
    NGINX_ENABLED_TARGET="/etc/nginx/sites-enabled/${NGINX_CONF_NAME}"
    NGINX_CONF_BASENAME="${NGINX_CONF_NAME%.conf}"
    WORKER_SERVICE_TARGET="/etc/systemd/system/${WORKER_SERVICE_NAME}"
    CRON_TARGET="/etc/cron.d/${CRON_FILE_NAME}"
}

is_placeholder_value() {
    local value="${1:-}"
    local normalized

    normalized="$(printf '%s' "$value" | tr '[:upper:]' '[:lower:]')"

    case "$normalized" in
        ""|example.com|rtrwnet.example.com|changeme|change-me|change_me|password|default)
            return 0
            ;;
    esac

    if [[ "$normalized" == *"ganti"* ]] || [[ "$normalized" == *"example.invalid"* ]]; then
        return 0
    fi

    return 1
}

assert_not_placeholder() {
    local var_name="$1"
    local value="${!var_name:-}"

    if is_placeholder_value "$value"; then
        die "Variabel ${var_name} masih memakai placeholder/default. Isi dengan nilai deployment yang real."
    fi
}

assert_boolean_var() {
    local var_name="$1"
    local value="${!var_name:-}"

    case "$value" in
        0|1)
            ;;
        *)
            die "Variabel ${var_name} hanya boleh bernilai 0 atau 1."
            ;;
    esac
}

validate_config() {
    local required_non_empty=(
        APP_DOMAIN
        APP_ROOT
        NGINX_CONF_NAME
        CI_ENV
        PHP_VERSION
        PHP_FPM_SOCK
        DB_HOST
        DB_PORT
        DB_NAME
        DB_USER
        DB_PASS
        WEB_USER
        WEB_GROUP
    )

    local var_name
    for var_name in "${required_non_empty[@]}"; do
        if [ -z "${!var_name:-}" ]; then
            if [ -n "$CONFIG_FILE" ]; then
                die "Variabel wajib kosong atau belum diisi: ${var_name}. Perbaiki file konfigurasi ${CONFIG_FILE}."
            fi
            die "Variabel wajib kosong atau belum diisi: ${var_name}. Gunakan template ${CONFIG_EXAMPLE_FILE} sebagai baseline konfigurasi."
        fi
    done

    for var_name in ENABLE_DB_MIGRATIONS ENABLE_REDIS ENABLE_WORKER ENABLE_CRON ENABLE_PHPMYADMIN; do
        assert_boolean_var "$var_name"
    done

    if [[ ! "$APP_ROOT" =~ ^/ ]]; then
        die "APP_ROOT harus berupa path absolute."
    fi

    if [ "$APP_ROOT" = "/" ]; then
        die "APP_ROOT tidak boleh diarahkan ke root filesystem."
    fi

    if [[ "$APP_ROOT" =~ [[:space:]] ]]; then
        die "APP_ROOT tidak boleh mengandung spasi."
    fi

    if [[ "$SOURCE_ROOT_CANONICAL" =~ [[:space:]] ]]; then
        die "SOURCE_ROOT tidak boleh mengandung spasi."
    fi

    if [[ "$APP_DOMAIN" =~ [[:space:]] ]]; then
        die "APP_DOMAIN tidak boleh mengandung spasi."
    fi

    local server_alias
    if [ -n "$APP_SERVER_ALIASES" ]; then
        for server_alias in $APP_SERVER_ALIASES; do
            if [[ ! "$server_alias" =~ ^[A-Za-z0-9._*-]+$ ]]; then
                die "APP_SERVER_ALIASES hanya boleh berisi hostname yang aman dipakai di Nginx."
            fi
        done
    fi

    if [[ ! "$NGINX_CONF_NAME" =~ ^[A-Za-z0-9._-]+\.conf$ ]]; then
        die "NGINX_CONF_NAME harus aman untuk nama file, contoh: rtrwnet.conf"
    fi

    if [[ ! "$CRON_FILE_NAME" =~ ^[A-Za-z0-9._-]+$ ]]; then
        die "CRON_FILE_NAME harus aman untuk nama file."
    fi

    if [[ ! "$WORKER_SERVICE_NAME" =~ ^[A-Za-z0-9._-]+\.service$ ]]; then
        die "WORKER_SERVICE_NAME harus aman untuk nama unit systemd."
    fi

    if [[ ! "$PHP_VERSION" =~ ^[0-9]+\.[0-9]+$ ]]; then
        die "PHP_VERSION harus memakai format mayor.minor, contoh: 8.1, 8.2, atau 8.3"
    fi

    if [[ ! "$DB_PORT" =~ ^[0-9]+$ ]]; then
        die "DB_PORT harus berupa angka."
    fi

    if [[ ! "$REDIS_PORT" =~ ^[0-9]+$ ]]; then
        die "REDIS_PORT harus berupa angka."
    fi

    if [[ ! "$REDIS_DB" =~ ^[0-9]+$ ]]; then
        die "REDIS_DB harus berupa angka bulat >= 0."
    fi

    if [[ ! "$DB_NAME" =~ ^[A-Za-z0-9_]+$ ]]; then
        die "DB_NAME hanya boleh berisi huruf, angka, dan underscore."
    fi

    if [[ ! "$DB_USER" =~ ^[A-Za-z0-9_]+$ ]]; then
        die "DB_USER hanya boleh berisi huruf, angka, dan underscore."
    fi

    if [[ ! "$WEB_USER" =~ ^[A-Za-z0-9._-]+$ ]]; then
        die "WEB_USER mengandung karakter yang tidak aman."
    fi

    if [[ ! "$WEB_GROUP" =~ ^[A-Za-z0-9._-]+$ ]]; then
        die "WEB_GROUP mengandung karakter yang tidak aman."
    fi

    if [[ ! "$PHPMYADMIN_URL" =~ ^/[A-Za-z0-9._/-]+$ ]]; then
        die "PHPMYADMIN_URL harus berupa path URL sederhana, misalnya /phpmyadmin"
    fi

    if [ ! -d "$SOURCE_ROOT_CANONICAL" ]; then
        die "SOURCE_ROOT tidak ditemukan: ${SOURCE_ROOT_CANONICAL}"
    fi

    if [ ! -f "${SOURCE_ROOT_CANONICAL}/index.php" ]; then
        die "Entry point aplikasi tidak ditemukan di SOURCE_ROOT: ${SOURCE_ROOT_CANONICAL}/index.php"
    fi

    if [ ! -f "$ENV_TEMPLATE_FILE" ]; then
        die "Template env canonical tidak ditemukan: ${ENV_TEMPLATE_FILE}"
    fi

    if [ ! -f "$NGINX_TEMPLATE_FILE" ]; then
        die "Template Nginx tidak ditemukan: ${NGINX_TEMPLATE_FILE}"
    fi

    if [ ! -f "$WORKER_TEMPLATE_FILE" ]; then
        die "Template worker service tidak ditemukan: ${WORKER_TEMPLATE_FILE}"
    fi

    if [ ! -f "$CRON_TEMPLATE_FILE" ]; then
        die "Template cron tidak ditemukan: ${CRON_TEMPLATE_FILE}"
    fi

    if [ ! -f "$PACKAGE_ALLOWLIST_FILE" ]; then
        die "package.allowlist tidak ditemukan: ${PACKAGE_ALLOWLIST_FILE}"
    fi

    if [ ! -f "$PACKAGE_DENYLIST_FILE" ]; then
        die "package.denylist tidak ditemukan: ${PACKAGE_DENYLIST_FILE}"
    fi

    if [ -n "$CONFIG_FILE" ] && path_is_within "$CONFIG_FILE" "$SOURCE_ROOT_CANONICAL"; then
        die "File konfigurasi installer berada di dalam SOURCE_ROOT (${CONFIG_FILE}). Pindahkan ke path di luar source tree, misalnya /root/rtrwnet-installer.env, agar secret tidak ikut build context."
    fi

    if [ "$ENABLE_CRON" = "1" ] && [ "$ENABLE_WORKER" != "1" ]; then
        die "ENABLE_CRON=1 membutuhkan ENABLE_WORKER=1 karena ada cron yang menulis job ke background queue."
    fi

    if [ "$ENABLE_REDIS" = "1" ]; then
        assert_not_placeholder REDIS_HOST
    fi

    assert_not_placeholder APP_DOMAIN
    assert_not_placeholder DB_PASS

    if [ -n "$DB_ROOT_PASS" ]; then
        assert_not_placeholder DB_ROOT_PASS
    fi

    local optional_secret_vars=(
        CI_ENCRYPTION_KEY
        PROVISIONING_CALLBACK_SECRET
        TELEGRAM_WEBHOOK_SECRET
        CRON_TOKEN
        MONITORING_CRON_TOKEN
    )

    local value
    for var_name in "${optional_secret_vars[@]}"; do
        value="${!var_name:-}"
        if [ -n "$value" ] && is_placeholder_value "$value"; then
            die "Variabel ${var_name} masih memakai placeholder. Kosongkan agar digenerate installer, atau isi secret yang benar."
        fi
    done

    if [ "$APP_ROOT" != "$SOURCE_ROOT_CANONICAL" ]; then
        if path_is_within "$APP_ROOT" "$SOURCE_ROOT_CANONICAL" || path_is_within "$SOURCE_ROOT_CANONICAL" "$APP_ROOT"; then
            die "APP_ROOT dan SOURCE_ROOT tidak boleh saling bersarang kecuali benar-benar path yang sama."
        fi
    fi
}

package_installed() {
    dpkg-query -W -f='${Status}' "$1" 2>/dev/null | grep -q "install ok installed"
}

apt_update_once() {
    if [ "$APT_UPDATED" -eq 0 ]; then
        log "Menjalankan apt-get update..."
        apt-get update
        APT_UPDATED=1
    fi
}

install_packages_if_missing() {
    local missing_packages=()
    local package_name

    for package_name in "$@"; do
        if ! package_installed "$package_name"; then
            missing_packages+=("$package_name")
        fi
    done

    if [ "${#missing_packages[@]}" -eq 0 ]; then
        log "Package sudah tersedia: $*"
        return
    fi

    apt_update_once
    log "Menginstall package: ${missing_packages[*]}"
    DEBIAN_FRONTEND=noninteractive apt-get install -y "${missing_packages[@]}"
}

ensure_base_packages() {
    install_packages_if_missing ca-certificates curl debconf-utils gettext-base rsync unzip
}

ensure_web_account() {
    if ! getent group "$WEB_GROUP" >/dev/null 2>&1; then
        groupadd --system "$WEB_GROUP"
        add_summary "Group web dibuat: ${WEB_GROUP}"
    fi

    if ! id "$WEB_USER" >/dev/null 2>&1; then
        useradd --system --gid "$WEB_GROUP" --home-dir /nonexistent --shell /usr/sbin/nologin "$WEB_USER"
        add_summary "User web dibuat: ${WEB_USER}"
    fi
}

collect_source_runtime_matches() {
    (
        cd "$SOURCE_ROOT_CANONICAL"

        if [ -d application/logs ]; then
            find application/logs -mindepth 1 \
                ! -path 'application/logs/index.html' \
                -print
        fi

        if [ -d application/cache ]; then
            find application/cache -mindepth 1 \
                ! -path 'application/cache/index.html' \
                ! -path 'application/cache/login_attempts' \
                ! -path 'application/cache/login_attempts/index.html' \
                -print
        fi

        local runtime_dir
        for runtime_dir in uploads public/uploads public/files storage writable tmp temp; do
            if [ -d "$runtime_dir" ] && find "$runtime_dir" -mindepth 1 -print -quit | grep -q .; then
                printf '%s\n' "$runtime_dir"
            fi
        done
    ) | sort -u
}

assert_source_context_safe() {
    local matches=()
    local line

    while IFS= read -r line; do
        [ -n "$line" ] || continue
        matches+=("$line")
    done < <(
        cd "$SOURCE_ROOT_CANONICAL" && find . -maxdepth 1 -type f \
            \( -name '.env' -o \( -name '.env.*' ! -name '.env.example' \) \) \
            -printf '%P\n' | sort
    )

    if [ -f "${INSTALLER_SOURCE_DIR}/config.env" ]; then
        matches+=("deployment/ubuntu-installer/config.env")
    fi

    while IFS= read -r line; do
        [ -n "$line" ] || continue
        matches+=("$line")
    done < <(collect_source_runtime_matches)

    if [ "${#matches[@]}" -gt 0 ]; then
        printf '[ERROR] Build context source tidak aman. Hapus artefak berikut dari SOURCE_ROOT sebelum install:\n' >&2
        printf ' - %s\n' "${matches[@]}" >&2
        die "Installer hard-fail karena live env atau runtime artefact terdeteksi di build context."
    fi
}

prepare_staging_directory() {
    STAGING_DIR="$(mktemp -d /tmp/rtrwnet-staging.XXXXXX)"
    add_summary "Staging package dibuat di ${STAGING_DIR}"
}

copy_allowlisted_paths_to_staging() {
    local rel_path

    log "Menyalin package staging dari allowlist..."

    (
        cd "$SOURCE_ROOT_CANONICAL"

        while IFS= read -r rel_path || [ -n "$rel_path" ]; do
            rel_path="${rel_path%$'\r'}"
            [[ -z "$rel_path" || "$rel_path" =~ ^[[:space:]]*# ]] && continue

            if [ ! -e "$rel_path" ]; then
                die "Path allowlist tidak ditemukan di SOURCE_ROOT: ${rel_path}"
            fi

            rsync -a --relative -- "$rel_path" "${STAGING_DIR}/"
        done < "$PACKAGE_ALLOWLIST_FILE"
    )
}

write_placeholder_html() {
    local target="$1"

    cat > "$target" <<'EOF'
<!DOCTYPE html>
<html>
<head>
    <title>403 Forbidden</title>
</head>
<body>
<p>Directory access is forbidden.</p>
</body>
</html>
EOF
}

sanitize_runtime_directories_in_staging() {
    log "Menyiapkan runtime directory kosong dari staging..."

    mkdir -p \
        "${STAGING_DIR}/application/logs" \
        "${STAGING_DIR}/application/cache/login_attempts"

    find "${STAGING_DIR}/application/logs" -mindepth 1 -delete || true
    find "${STAGING_DIR}/application/cache" -mindepth 1 -delete || true

    mkdir -p "${STAGING_DIR}/application/cache/login_attempts"
    write_placeholder_html "${STAGING_DIR}/application/logs/index.html"
    write_placeholder_html "${STAGING_DIR}/application/cache/index.html"
    write_placeholder_html "${STAGING_DIR}/application/cache/login_attempts/index.html"
}

collect_denylist_matches() {
    local root="$1"

    (
        cd "$root"
        shopt -s dotglob globstar nullglob

        local pattern is_exception match
        declare -A denied=()
        declare -A allowed=()

        while IFS= read -r pattern || [ -n "$pattern" ]; do
            pattern="${pattern%$'\r'}"
            [[ -z "$pattern" || "$pattern" =~ ^[[:space:]]*# ]] && continue

            is_exception=0
            if [[ "$pattern" == !* ]]; then
                is_exception=1
                pattern="${pattern#!}"
            fi

            for match in $pattern; do
                [ -e "$match" ] || continue
                match="${match%/}"
                if [ "$is_exception" -eq 1 ]; then
                    allowed["$match"]=1
                else
                    denied["$match"]=1
                fi
            done
        done < "$PACKAGE_DENYLIST_FILE"

        for match in "${!denied[@]}"; do
            if [ -n "${allowed[$match]+x}" ]; then
                continue
            fi
            printf '%s\n' "$match"
        done | sort -u
    )
}

validate_staging_package() {
    local matches=()
    local line

    while IFS= read -r line; do
        [ -n "$line" ] || continue
        matches+=("$line")
    done < <(collect_denylist_matches "$STAGING_DIR")

    if [ "${#matches[@]}" -gt 0 ]; then
        printf '[ERROR] Staging package masih mengandung path terlarang:\n' >&2
        printf ' - %s\n' "${matches[@]}" >&2
        die "Validasi package.denylist gagal."
    fi

    if [ -f "${STAGING_DIR}/.env" ]; then
        die "Staging package tidak boleh mengandung .env live."
    fi
}

ensure_safe_app_root_for_fresh_install() {
    if [ -e "$APP_ROOT" ] && [ ! -d "$APP_ROOT" ]; then
        die "APP_ROOT sudah ada tetapi bukan direktori: ${APP_ROOT}"
    fi

    if [ "$APP_ROOT" != "$SOURCE_ROOT_CANONICAL" ] && [ -d "$APP_ROOT" ]; then
        if find "$APP_ROOT" -mindepth 1 -print -quit | grep -q .; then
            die "APP_ROOT sudah berisi file. Installer final ini difokuskan untuk fresh install; kosongkan ${APP_ROOT} atau gunakan clean package di path tujuan."
        fi
    fi

    mkdir -p "$APP_ROOT"
}

deploy_staging_to_app_root() {
    log "Mendeploy staging package ke APP_ROOT..."

    ensure_safe_app_root_for_fresh_install
    rsync -a --delete "${STAGING_DIR}/" "${APP_ROOT}/"
    add_summary "Staging package dideploy ke ${APP_ROOT}"
}

ensure_nginx() {
    install_packages_if_missing nginx

    systemctl enable nginx >/dev/null 2>&1 || true
    systemctl start nginx
    add_summary "Nginx aktif."
}

resolve_php_binary() {
    if [ -z "$PHP_BIN" ]; then
        if [ -x "/usr/bin/php${PHP_VERSION}" ]; then
            PHP_BIN="/usr/bin/php${PHP_VERSION}"
        else
            PHP_BIN="$(command -v php || true)"
        fi
    fi

    if [ -z "$PHP_BIN" ] || [ ! -x "$PHP_BIN" ]; then
        die "PHP_BIN tidak valid. Isi path binary PHP CLI yang benar."
    fi

    local cli_version
    cli_version="$("$PHP_BIN" -r 'echo PHP_MAJOR_VERSION.".".PHP_MINOR_VERSION;')"
    if [ "$cli_version" != "$PHP_VERSION" ]; then
        die "PHP_BIN (${PHP_BIN}) memakai versi ${cli_version}, tetapi PHP_VERSION dikonfigurasi ${PHP_VERSION}. Samakan keduanya agar worker/cron konsisten."
    fi
}

ensure_php() {
    local php_packages=(
        "php${PHP_VERSION}-fpm"
        "php${PHP_VERSION}-mysql"
        "php${PHP_VERSION}-cli"
        "php${PHP_VERSION}-curl"
        "php${PHP_VERSION}-mbstring"
        "php${PHP_VERSION}-xml"
        "php${PHP_VERSION}-zip"
        "php${PHP_VERSION}-gd"
        "php${PHP_VERSION}-intl"
        "php${PHP_VERSION}-bcmath"
        "php${PHP_VERSION}-opcache"
        "php${PHP_VERSION}-readline"
    )

    if [ "$ENABLE_REDIS" = "1" ]; then
        php_packages+=("php${PHP_VERSION}-redis")
    fi

    install_packages_if_missing "${php_packages[@]}"
    resolve_php_binary

    systemctl enable "php${PHP_VERSION}-fpm" >/dev/null 2>&1 || true
    systemctl restart "php${PHP_VERSION}-fpm"

    if [ ! -S "$PHP_FPM_SOCK" ]; then
        die "Socket PHP-FPM tidak ditemukan: ${PHP_FPM_SOCK}. Periksa PHP_VERSION dan PHP_FPM_SOCK."
    fi

    add_summary "PHP-FPM php${PHP_VERSION} aktif dengan socket ${PHP_FPM_SOCK}."
}

detect_mysql_service() {
    if systemctl list-unit-files --type=service | grep -q '^mysql\.service'; then
        MYSQL_SERVICE="mysql"
    elif systemctl list-unit-files --type=service | grep -q '^mariadb\.service'; then
        MYSQL_SERVICE="mariadb"
    else
        MYSQL_SERVICE="mysql"
    fi
}

ensure_database_server() {
    install_packages_if_missing default-mysql-server default-mysql-client

    detect_mysql_service
    systemctl enable "$MYSQL_SERVICE" >/dev/null 2>&1 || true
    systemctl start "$MYSQL_SERVICE"

    local wait_count=0
    until \
        mysqladmin --protocol=socket ping >/dev/null 2>&1 || \
        { [ -n "$DB_ROOT_PASS" ] && mysqladmin --protocol=socket -uroot -p"${DB_ROOT_PASS}" ping >/dev/null 2>&1; } || \
        { [ -n "$DB_ROOT_PASS" ] && mysqladmin -h127.0.0.1 -uroot -p"${DB_ROOT_PASS}" ping >/dev/null 2>&1; }
    do
        wait_count=$((wait_count + 1))
        if [ "$wait_count" -ge 30 ]; then
            die "Service database belum siap setelah menunggu 30 detik."
        fi
        sleep 1
    done

    add_summary "Service database aktif: ${MYSQL_SERVICE}."
}

ensure_redis_stack() {
    if [ "$ENABLE_REDIS" != "1" ]; then
        add_summary "Redis dinonaktifkan. Queue akan memakai fallback database."
        return
    fi

    install_packages_if_missing redis-server redis-tools "php${PHP_VERSION}-redis"

    systemctl enable redis-server >/dev/null 2>&1 || true
    systemctl restart redis-server

    if [ "$(redis-cli ping 2>/dev/null || true)" != "PONG" ]; then
        die "Redis aktif dipilih tetapi redis-server tidak merespons PONG."
    fi

    add_summary "Redis aktif dan queue driver akan memakai Redis."
}

mysql_escape() {
    local value="$1"
    value="${value//\\/\\\\}"
    value="${value//\'/\\\'}"
    printf '%s' "$value"
}

dotenv_escape() {
    local value="$1"
    value="${value//\\/\\\\}"
    value="${value//\"/\\\"}"
    printf '%s' "$value"
}

read_project_env_value() {
    local env_file="$1"
    local key="$2"
    local line value

    if [ ! -f "$env_file" ]; then
        return 0
    fi

    line="$(grep -E "^(export[[:space:]]+)?${key}=" "$env_file" | tail -n 1 || true)"
    if [ -z "$line" ]; then
        return 0
    fi

    line="${line#export }"
    value="${line#*=}"
    value="${value%$'\r'}"

    if [[ "$value" == \"*\" && "$value" == *\" ]]; then
        value="${value:1:${#value}-2}"
        value="${value//\\\\/\\}"
        value="${value//\\\"/\"}"
    elif [[ "$value" == \'*\' && "$value" == *\' ]]; then
        value="${value:1:${#value}-2}"
    else
        value="${value%% #*}"
    fi

    printf '%s' "$value"
}

generate_runtime_secret() {
    "$PHP_BIN" -r 'echo bin2hex(random_bytes(32));'
}

resolve_runtime_env_value() {
    local env_file="$1"
    local key="$2"
    local configured_value="${3:-}"
    local fallback_mode="${4:-}"
    local existing_value

    if [ -n "$configured_value" ]; then
        printf '%s' "$configured_value"
        return 0
    fi

    existing_value="$(read_project_env_value "$env_file" "$key")"
    if [ -n "$existing_value" ]; then
        printf '%s' "$existing_value"
        return 0
    fi

    case "$fallback_mode" in
        generate)
            generate_runtime_secret
            ;;
        *)
            printf '%s' "$fallback_mode"
            ;;
    esac
}

mysql_root_exec() {
    local sql="$1"

    if mysql --protocol=socket -uroot -Nse "SELECT 1;" >/dev/null 2>&1; then
        mysql --protocol=socket -uroot -e "$sql"
        return
    fi

    if [ -n "$DB_ROOT_PASS" ] && mysql --protocol=socket -uroot -p"${DB_ROOT_PASS}" -Nse "SELECT 1;" >/dev/null 2>&1; then
        mysql --protocol=socket -uroot -p"${DB_ROOT_PASS}" -e "$sql"
        return
    fi

    if [ -n "$DB_ROOT_PASS" ] && mysql -h127.0.0.1 -uroot -p"${DB_ROOT_PASS}" -Nse "SELECT 1;" >/dev/null 2>&1; then
        mysql -h127.0.0.1 -uroot -p"${DB_ROOT_PASS}" -e "$sql"
        return
    fi

    die "Tidak bisa login sebagai MySQL root. Periksa service database dan nilai DB_ROOT_PASS."
}

mysql_root_query() {
    local sql="$1"

    if mysql --protocol=socket -uroot -Nse "SELECT 1;" >/dev/null 2>&1; then
        mysql --protocol=socket -uroot -Nse "$sql"
        return
    fi

    if [ -n "$DB_ROOT_PASS" ] && mysql --protocol=socket -uroot -p"${DB_ROOT_PASS}" -Nse "SELECT 1;" >/dev/null 2>&1; then
        mysql --protocol=socket -uroot -p"${DB_ROOT_PASS}" -Nse "$sql"
        return
    fi

    if [ -n "$DB_ROOT_PASS" ] && mysql -h127.0.0.1 -uroot -p"${DB_ROOT_PASS}" -Nse "SELECT 1;" >/dev/null 2>&1; then
        mysql -h127.0.0.1 -uroot -p"${DB_ROOT_PASS}" -Nse "$sql"
        return
    fi

    die "Tidak bisa menjalankan query MySQL root."
}

mysql_root_import_db() {
    local database_name="$1"
    local sql_file="$2"

    if mysql --protocol=socket -uroot -Nse "SELECT 1;" >/dev/null 2>&1; then
        mysql --protocol=socket -uroot "$database_name" < "$sql_file"
        return
    fi

    if [ -n "$DB_ROOT_PASS" ] && mysql --protocol=socket -uroot -p"${DB_ROOT_PASS}" -Nse "SELECT 1;" >/dev/null 2>&1; then
        mysql --protocol=socket -uroot -p"${DB_ROOT_PASS}" "$database_name" < "$sql_file"
        return
    fi

    if [ -n "$DB_ROOT_PASS" ] && mysql -h127.0.0.1 -uroot -p"${DB_ROOT_PASS}" -Nse "SELECT 1;" >/dev/null 2>&1; then
        mysql -h127.0.0.1 -uroot -p"${DB_ROOT_PASS}" "$database_name" < "$sql_file"
        return
    fi

    die "Tidak bisa import SQL ke database ${database_name}."
}

secure_mysql_installation() {
    log "Menjalankan hardening dasar database..."

    mysql_root_exec "DELETE FROM mysql.user WHERE User='';"
    mysql_root_exec "DELETE FROM mysql.db WHERE Db='test' OR Db='test\\_%';"
    mysql_root_exec "DROP DATABASE IF EXISTS test;"
    mysql_root_exec "DELETE FROM mysql.user WHERE User='root' AND Host NOT IN ('localhost', '127.0.0.1', '::1');"
    mysql_root_exec "FLUSH PRIVILEGES;"

    if [ -n "$DB_ROOT_PASS" ]; then
        local db_root_pass_escaped
        db_root_pass_escaped="$(mysql_escape "$DB_ROOT_PASS")"
        mysql_root_exec "ALTER USER 'root'@'localhost' IDENTIFIED BY '${db_root_pass_escaped}';"
        mysql_root_exec "FLUSH PRIVILEGES;"
        add_summary "Password root database telah diatur/diupdate."
    else
        add_summary "DB_ROOT_PASS kosong. Root database mengikuti metode autentikasi lokal yang sudah ada."
    fi

    add_summary "Hardening dasar database selesai."
}

ensure_database_and_user() {
    local db_name_escaped db_user_escaped db_pass_escaped
    db_name_escaped="$(mysql_escape "$DB_NAME")"
    db_user_escaped="$(mysql_escape "$DB_USER")"
    db_pass_escaped="$(mysql_escape "$DB_PASS")"

    mysql_root_exec "CREATE DATABASE IF NOT EXISTS \`${db_name_escaped}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"
    mysql_root_exec "CREATE USER IF NOT EXISTS '${db_user_escaped}'@'localhost' IDENTIFIED BY '${db_pass_escaped}';"
    mysql_root_exec "ALTER USER '${db_user_escaped}'@'localhost' IDENTIFIED BY '${db_pass_escaped}';"
    mysql_root_exec "CREATE USER IF NOT EXISTS '${db_user_escaped}'@'127.0.0.1' IDENTIFIED BY '${db_pass_escaped}';"
    mysql_root_exec "ALTER USER '${db_user_escaped}'@'127.0.0.1' IDENTIFIED BY '${db_pass_escaped}';"
    mysql_root_exec "GRANT ALL PRIVILEGES ON \`${db_name_escaped}\`.* TO '${db_user_escaped}'@'localhost';"
    mysql_root_exec "GRANT ALL PRIVILEGES ON \`${db_name_escaped}\`.* TO '${db_user_escaped}'@'127.0.0.1';"
    mysql_root_exec "FLUSH PRIVILEGES;"

    add_summary "Database ${DB_NAME} dan user ${DB_USER} siap dipakai."
}

resolve_sql_file() {
    local candidate

    if [ -z "$SQL_FILE" ]; then
        return 1
    fi

    for candidate in \
        "$SQL_FILE" \
        "${CONFIG_DIR:+${CONFIG_DIR}/${SQL_FILE}}" \
        "${PWD}/${SQL_FILE}" \
        "${SCRIPT_DIR}/${SQL_FILE}"
    do
        [ -n "$candidate" ] || continue
        if [ -f "$candidate" ]; then
            candidate="$(canonical_path "$candidate")"
            if path_is_within "$candidate" "$SOURCE_ROOT_CANONICAL"; then
                die "SQL_FILE berada di dalam SOURCE_ROOT (${candidate}). Letakkan seed schema/dump installer di luar build context agar tidak ikut packaging."
            fi
            printf '%s\n' "$candidate"
            return 0
        fi
    done

    return 1
}

import_sql_if_needed() {
    local resolved_sql_file=""
    local table_count="0"
    local db_name_escaped

    db_name_escaped="$(mysql_escape "$DB_NAME")"
    table_count="$(mysql_root_query "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema='${db_name_escaped}';")"
    table_count="${table_count:-0}"

    if [ -z "$SQL_FILE" ]; then
        add_summary "SQL_FILE kosong. Import schema awal dilewati."
        return
    fi

    if ! resolved_sql_file="$(resolve_sql_file)"; then
        die "SQL_FILE diisi tetapi file tidak ditemukan: ${SQL_FILE}"
    fi

    if [ "$table_count" -gt 0 ]; then
        warn "Database ${DB_NAME} sudah memiliki ${table_count} tabel. Import SQL dilewati untuk menghindari duplikasi."
        add_summary "Import SQL dilewati karena database ${DB_NAME} tidak kosong."
        return
    fi

    log "Mengimport SQL dari ${resolved_sql_file} ke database ${DB_NAME}..."
    mysql_root_import_db "$DB_NAME" "$resolved_sql_file"
    add_summary "Import SQL selesai dari ${resolved_sql_file}."
}

write_project_env() {
    log "Merender .env runtime dari .env.example canonical..."

    local project_env_file="${APP_ROOT}/.env"
    local existing_env_file="${APP_ROOT}/.env"
    local temp_env_file
    local key line existing_value rendered_value

    declare -A replacements=()

    replacements[CI_ENV]="$(resolve_runtime_env_value "$existing_env_file" "CI_ENV" "${CI_ENV:-}" "production")"
    replacements[DB_HOST]="$DB_HOST"
    replacements[DB_PORT]="$DB_PORT"
    replacements[DB_NAME]="$DB_NAME"
    replacements[DB_USER]="$DB_USER"
    replacements[DB_PASS]="$DB_PASS"
    replacements[CI_ENCRYPTION_KEY]="$(resolve_runtime_env_value "$existing_env_file" "CI_ENCRYPTION_KEY" "${CI_ENCRYPTION_KEY:-}" "generate")"
    replacements[PROVISIONING_CALLBACK_SECRET]="$(resolve_runtime_env_value "$existing_env_file" "PROVISIONING_CALLBACK_SECRET" "${PROVISIONING_CALLBACK_SECRET:-}" "generate")"
    replacements[TELEGRAM_WEBHOOK_SECRET]="$(resolve_runtime_env_value "$existing_env_file" "TELEGRAM_WEBHOOK_SECRET" "${TELEGRAM_WEBHOOK_SECRET:-}" "generate")"
    replacements[CRON_TOKEN]="$(resolve_runtime_env_value "$existing_env_file" "CRON_TOKEN" "${CRON_TOKEN:-}" "generate")"
    replacements[MONITORING_CRON_TOKEN]="$(resolve_runtime_env_value "$existing_env_file" "MONITORING_CRON_TOKEN" "${MONITORING_CRON_TOKEN:-}" "generate")"
    replacements[TELEGRAM_BOT_TOKEN]="$(resolve_runtime_env_value "$existing_env_file" "TELEGRAM_BOT_TOKEN" "${TELEGRAM_BOT_TOKEN:-}" "")"
    replacements[QUEUE_DRIVER]="$QUEUE_DRIVER"
    replacements[QUEUE_ENABLE_ASYNC]="$QUEUE_ENABLE_ASYNC"
    replacements[REDIS_HOST]="$(resolve_runtime_env_value "$existing_env_file" "REDIS_HOST" "${REDIS_HOST:-}" "127.0.0.1")"
    replacements[REDIS_PORT]="$(resolve_runtime_env_value "$existing_env_file" "REDIS_PORT" "${REDIS_PORT:-}" "6379")"
    replacements[REDIS_DB]="$(resolve_runtime_env_value "$existing_env_file" "REDIS_DB" "${REDIS_DB:-}" "0")"
    replacements[REDIS_TIMEOUT]="$(resolve_runtime_env_value "$existing_env_file" "REDIS_TIMEOUT" "" "2.0")"
    replacements[REDIS_PASSWORD]="$(resolve_runtime_env_value "$existing_env_file" "REDIS_PASSWORD" "${REDIS_PASSWORD:-}" "")"
    replacements[REDIS_PREFIX]="$(resolve_runtime_env_value "$existing_env_file" "REDIS_PREFIX" "${REDIS_PREFIX:-}" "rtrwnet:")"

    temp_env_file="$(mktemp)"

    if [ -f "$project_env_file" ]; then
        backup_path "$project_env_file"
    fi

    while IFS= read -r line || [ -n "$line" ]; do
        line="${line%$'\r'}"

        if [[ "$line" =~ ^([A-Za-z_][A-Za-z0-9_]*)= ]]; then
            key="${BASH_REMATCH[1]}"

            if [ -n "${replacements[$key]+x}" ]; then
                rendered_value="${replacements[$key]}"
                printf '%s="%s"\n' "$key" "$(dotenv_escape "$rendered_value")" >> "$temp_env_file"
                continue
            fi

            existing_value="$(read_project_env_value "$existing_env_file" "$key")"
            if [ -n "$existing_value" ]; then
                printf '%s="%s"\n' "$key" "$(dotenv_escape "$existing_value")" >> "$temp_env_file"
                continue
            fi
        fi

        printf '%s\n' "$line" >> "$temp_env_file"
    done < "$ENV_TEMPLATE_FILE"

    mv "$temp_env_file" "$project_env_file"
    chown "root:${WEB_GROUP}" "$project_env_file"
    chmod 0640 "$project_env_file"

    add_summary ".env runtime dirender ulang dari ${ENV_TEMPLATE_FILE}"
    add_summary "QUEUE_DRIVER di-set ke ${QUEUE_DRIVER}; QUEUE_ENABLE_ASYNC di-set ke ${QUEUE_ENABLE_ASYNC}."
}

run_as_web_user() {
    local cmd=("$@")
    runuser -u "$WEB_USER" -- "${cmd[@]}"
}

run_database_migrations() {
    if [ "$ENABLE_DB_MIGRATIONS" != "1" ]; then
        add_summary "Migration aplikasi dilewati karena ENABLE_DB_MIGRATIONS=0."
        return
    fi

    log "Menjalankan migration aplikasi..."
    run_as_web_user "$PHP_BIN" "${APP_ROOT}/index.php" migrate latest
    add_summary "Migration aplikasi ke latest berhasil dijalankan."
}

assert_database_schema_ready() {
    local required_tables=(users customers routers background_jobs)
    local table count missing=()

    for table in "${required_tables[@]}"; do
        count="$(mysql_root_query "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema='$(mysql_escape "$DB_NAME")' AND table_name='$(mysql_escape "$table")';")"
        count="${count:-0}"
        if [ "$count" -eq 0 ]; then
            missing+=("$table")
        fi
    done

    if [ "${#missing[@]}" -gt 0 ]; then
        die "Schema aplikasi belum lengkap setelah import/migration. Tabel penting yang belum ada: ${missing[*]}. Sediakan SQL_FILE schema final yang aman jika database masih kosong."
    fi
}

ensure_phpmyadmin() {
    if [ "$ENABLE_PHPMYADMIN" != "1" ]; then
        add_summary "phpMyAdmin dilewati karena ENABLE_PHPMYADMIN=0."
        return
    fi

    log "Menyiapkan phpMyAdmin..."

    printf 'phpmyadmin phpmyadmin/reconfigure-webserver multiselect \n' | debconf-set-selections || true
    printf 'phpmyadmin phpmyadmin/dbconfig-install boolean false\n' | debconf-set-selections || true
    install_packages_if_missing phpmyadmin

    if [ ! -d /usr/share/phpmyadmin ]; then
        die "Folder phpMyAdmin tidak ditemukan setelah instalasi."
    fi

    mkdir -p /var/lib/phpmyadmin/tmp
    chown -R "$WEB_USER:$WEB_GROUP" /var/lib/phpmyadmin
    chmod -R u=rwX,g=rwX,o= /var/lib/phpmyadmin

    local phpmyadmin_local_conf="/etc/phpmyadmin/conf.d/99-rtrwnet-local.php"
    backup_path "$phpmyadmin_local_conf"

    cat > "$phpmyadmin_local_conf" <<'EOF'
<?php
$cfg['TempDir'] = '/var/lib/phpmyadmin/tmp';
EOF

    chown "root:${WEB_GROUP}" "$phpmyadmin_local_conf"
    chmod 0640 "$phpmyadmin_local_conf"
    add_summary "phpMyAdmin siap dari package distro."
}

set_project_permissions() {
    log "Mengatur permission project..."

    chown -R "root:${WEB_GROUP}" "$APP_ROOT"
    chmod -R u=rwX,g=rX,o= "$APP_ROOT"

    local writable_dirs=(
        "application/cache"
        "application/logs"
    )
    local rel_dir abs_dir

    for rel_dir in "${writable_dirs[@]}"; do
        abs_dir="${APP_ROOT}/${rel_dir}"
        mkdir -p "$abs_dir"
        chown -R "${WEB_USER}:${WEB_GROUP}" "$abs_dir"
        chmod -R u=rwX,g=rwX,o= "$abs_dir"
        add_summary "Writable diaktifkan: ${abs_dir}"
    done

    if [ -f "${APP_ROOT}/.env" ]; then
        chown "root:${WEB_GROUP}" "${APP_ROOT}/.env"
        chmod 0640 "${APP_ROOT}/.env"
    fi
}

deploy_nginx_config() {
    log "Merender konfigurasi Nginx..."

    backup_path "$NGINX_CONF_TARGET"
    backup_path "$NGINX_ENABLED_TARGET"

    local rendered_conf
    rendered_conf="$(mktemp)"

    export APP_SERVER_NAMES APP_ROOT PHP_FPM_SOCK PHPMYADMIN_URL NGINX_CONF_BASENAME
    envsubst '${APP_SERVER_NAMES} ${APP_ROOT} ${PHP_FPM_SOCK} ${PHPMYADMIN_URL} ${NGINX_CONF_BASENAME}' \
        < "$NGINX_TEMPLATE_FILE" \
        > "$rendered_conf"

    if [ "$ENABLE_PHPMYADMIN" != "1" ]; then
        sed -i '/# PHPMYADMIN-BEGIN/,/# PHPMYADMIN-END/d' "$rendered_conf"
    fi

    mv "$rendered_conf" "$NGINX_CONF_TARGET"
    chmod 0644 "$NGINX_CONF_TARGET"

    if [ -e /etc/nginx/sites-enabled/default ] || [ -L /etc/nginx/sites-enabled/default ]; then
        backup_path /etc/nginx/sites-enabled/default
        rm -f /etc/nginx/sites-enabled/default
        add_summary "Default Nginx site dinonaktifkan."
    fi

    ln -sfn "$NGINX_CONF_TARGET" "$NGINX_ENABLED_TARGET"

    nginx -t
    systemctl reload nginx
    add_summary "Nginx site diaktifkan: ${NGINX_CONF_TARGET}"
}

build_worker_dependency_lines() {
    local after_targets=("network.target")
    local wants_targets=()

    if [ -n "$MYSQL_SERVICE" ]; then
        after_targets+=("${MYSQL_SERVICE}.service")
    fi

    if [ "$ENABLE_REDIS" = "1" ]; then
        after_targets+=("redis-server.service")
        wants_targets+=("redis-server.service")
    fi

    WORKER_AFTER_LINE="After=${after_targets[*]}"
    WORKER_WANTS_LINE=""
    if [ "${#wants_targets[@]}" -gt 0 ]; then
        WORKER_WANTS_LINE="Wants=${wants_targets[*]}"
    fi
}

setup_worker_service() {
    if [ "$ENABLE_WORKER" != "1" ]; then
        add_summary "Worker service dilewati karena ENABLE_WORKER=0."
        return
    fi

    log "Merender worker service..."
    backup_path "$WORKER_SERVICE_TARGET"

    build_worker_dependency_lines

    local rendered_service
    rendered_service="$(mktemp)"

    export APP_NAME WEB_USER WEB_GROUP APP_ROOT PHP_BIN WORKER_AFTER_LINE WORKER_WANTS_LINE
    envsubst '${APP_NAME} ${WEB_USER} ${WEB_GROUP} ${APP_ROOT} ${PHP_BIN} ${WORKER_AFTER_LINE} ${WORKER_WANTS_LINE}' \
        < "$WORKER_TEMPLATE_FILE" \
        > "$rendered_service"

    mv "$rendered_service" "$WORKER_SERVICE_TARGET"
    chmod 0644 "$WORKER_SERVICE_TARGET"

    systemctl daemon-reload
    systemctl enable "$WORKER_SERVICE_NAME" >/dev/null 2>&1 || true
    systemctl restart "$WORKER_SERVICE_NAME"
    add_summary "Worker service aktif: ${WORKER_SERVICE_TARGET}"
}

setup_cron_file() {
    if [ "$ENABLE_CRON" != "1" ]; then
        add_summary "Cron project dilewati karena ENABLE_CRON=0."
        return
    fi

    log "Merender cron file..."
    backup_path "$CRON_TARGET"

    local rendered_cron
    rendered_cron="$(mktemp)"

    export WEB_USER PHP_BIN APP_ROOT
    envsubst '${WEB_USER} ${PHP_BIN} ${APP_ROOT}' \
        < "$CRON_TEMPLATE_FILE" \
        > "$rendered_cron"

    install -o root -g root -m 0644 "$rendered_cron" "$CRON_TARGET"
    rm -f "$rendered_cron"
    add_summary "Cron project aktif: ${CRON_TARGET}"
}

verify_service_active() {
    local service_name="$1"
    local label="$2"

    if systemctl is-active --quiet "$service_name"; then
        add_verification "${label}: active"
        return
    fi

    die "Verifikasi gagal: service ${service_name} tidak aktif."
}

smoke_verify() {
    log "Menjalankan smoke verification..."

    nginx -t >/dev/null 2>&1 || die "Verifikasi gagal: nginx -t"
    add_verification "nginx syntax: ok"
    verify_service_active nginx "nginx service"
    verify_service_active "php${PHP_VERSION}-fpm" "php-fpm service"
    verify_service_active "$MYSQL_SERVICE" "database service"

    "$PHP_BIN" -v >/dev/null 2>&1 || die "Verifikasi gagal: PHP CLI tidak bisa dijalankan."
    add_verification "php cli: ${PHP_BIN}"

    mysql -h"$DB_HOST" -P"$DB_PORT" -u"$DB_USER" -p"$DB_PASS" "$DB_NAME" -Nse 'SELECT 1;' >/dev/null 2>&1 || \
        die "Verifikasi gagal: koneksi database aplikasi."
    add_verification "database app login: ok"

    if [ "$ENABLE_REDIS" = "1" ]; then
        verify_service_active redis-server "redis service"
        if [ "$(redis-cli ping 2>/dev/null || true)" != "PONG" ]; then
            die "Verifikasi gagal: redis ping."
        fi
        add_verification "redis ping: PONG"
    else
        add_verification "redis: disabled, queue driver database"
    fi

    if [ ! -f "${APP_ROOT}/.env" ]; then
        die "Verifikasi gagal: ${APP_ROOT}/.env tidak ditemukan."
    fi

    if [ "$(stat -c '%a' "${APP_ROOT}/.env")" != "640" ]; then
        die "Verifikasi gagal: permission .env harus 640."
    fi
    add_verification ".env runtime: present with 640 permission"

    if [ "$(read_project_env_value "${APP_ROOT}/.env" "QUEUE_DRIVER")" != "$QUEUE_DRIVER" ]; then
        die "Verifikasi gagal: QUEUE_DRIVER di .env tidak sesuai keputusan installer."
    fi
    add_verification "queue driver: ${QUEUE_DRIVER}"

    if [ "$ENABLE_WORKER" = "1" ]; then
        verify_service_active "$WORKER_SERVICE_NAME" "worker service"
        run_as_web_user "$PHP_BIN" "${APP_ROOT}/index.php" worker run once 1 >/dev/null 2>&1 || \
            die "Verifikasi gagal: worker CLI smoke."
        add_verification "worker cli smoke: ok"
    else
        add_verification "worker: disabled"
    fi

    if [ "$ENABLE_CRON" = "1" ]; then
        if [ ! -f "$CRON_TARGET" ]; then
            die "Verifikasi gagal: cron file tidak ditemukan di ${CRON_TARGET}"
        fi
        add_verification "cron file: ${CRON_TARGET}"
    else
        add_verification "cron: disabled"
    fi

    local http_status
    http_status="$(curl -sS -o /dev/null -w '%{http_code}' --max-time 15 -H "Host: ${APP_DOMAIN}" http://127.0.0.1/ || true)"
    case "$http_status" in
        200|301|302|303|307|308|401|403)
            add_verification "http smoke: ${http_status}"
            ;;
        *)
            die "Verifikasi gagal: HTTP smoke test memberi status ${http_status}."
            ;;
    esac
}

print_summary() {
    printf '\n'
    printf '============================================================\n'
    printf ' Deployment Summary\n'
    printf '============================================================\n'
    printf 'App Name        : %s\n' "$APP_NAME"
    printf 'App Domain      : %s\n' "$APP_DOMAIN"
    printf 'Source Root     : %s\n' "$SOURCE_ROOT_CANONICAL"
    printf 'App Root        : %s\n' "$APP_ROOT"
    printf 'OS Target       : %s\n' "$OS_PRETTY_NAME"
    printf 'Nginx Conf      : %s\n' "$NGINX_CONF_TARGET"
    printf 'PHP-FPM         : php%s-fpm (%s)\n' "$PHP_VERSION" "$PHP_FPM_SOCK"
    printf 'PHP CLI         : %s\n' "$PHP_BIN"
    printf 'Database        : %s / %s\n' "$DB_NAME" "$DB_USER"
    printf 'Queue Driver    : %s\n' "$QUEUE_DRIVER"
    printf 'Worker          : %s\n' "$( [ "$ENABLE_WORKER" = "1" ] && printf '%s' "$WORKER_SERVICE_TARGET" || printf 'disabled' )"
    printf 'Cron            : %s\n' "$( [ "$ENABLE_CRON" = "1" ] && printf '%s' "$CRON_TARGET" || printf 'disabled' )"
    printf 'App Env         : %s/.env\n' "$APP_ROOT"
    printf '\n'
    printf 'Tindakan yang dilakukan:\n'

    local item
    for item in "${SUMMARY_ITEMS[@]}"; do
        printf ' - %s\n' "$item"
    done

    printf '\n'
    printf 'Smoke verification:\n'
    for item in "${VERIFICATION_ITEMS[@]}"; do
        printf ' - %s\n' "$item"
    done
    printf '============================================================\n'
}

main() {
    require_root
    detect_supported_os
    load_config
    normalize_config
    validate_config
    assert_source_context_safe

    ensure_base_packages
    ensure_web_account
    prepare_staging_directory
    copy_allowlisted_paths_to_staging
    sanitize_runtime_directories_in_staging
    validate_staging_package
    deploy_staging_to_app_root

    ensure_nginx
    ensure_php
    ensure_database_server
    ensure_redis_stack

    secure_mysql_installation
    ensure_database_and_user
    import_sql_if_needed
    write_project_env
    set_project_permissions
    run_database_migrations
    assert_database_schema_ready

    ensure_phpmyadmin
    deploy_nginx_config
    setup_worker_service
    setup_cron_file
    smoke_verify
    print_summary
}

if [[ "${BASH_SOURCE[0]}" == "$0" ]]; then
    main "$@"
fi
